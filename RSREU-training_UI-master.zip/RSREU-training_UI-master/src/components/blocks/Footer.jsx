import React from 'react';

export const Footer = () => (
  <footer>
    <a id="settings_button">
      <div></div>
    </a>
    <a id="help_button">
      <div></div>
    </a>
  </footer>
);
